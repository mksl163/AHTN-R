package ai.ahtn;

import java.util.LinkedList;
import java.util.List;

import ai.ahtn.domain.DomainDefinition;
import ai.ahtn.domain.MethodDecomposition;
import ai.ahtn.domain.PredefinedOperators;
import ai.ahtn.domain.Term;
import ai.ahtn.planner.AdversarialBoundedDepthPlannerAlphaBetaforEnemyStrategy;
import ai.core.AI;
import ai.evaluation.EvaluationFunction;
import rts.GameState;
import rts.PartiallyObservableGameState;
import rts.PlayerAction;
import rts.UnitAction;
import rts.units.Unit;
import util.Pair;

public class AHTNForEnemyStrategy extends AHTNAI {

	public DomainDefinition ddEnemy=null;
	
	public AHTNForEnemyStrategy(String a_domainFileName, int available_time, int max_playouts, int playoutLookahead,
			EvaluationFunction a_ef, AI a_playoutAI) throws Exception {
		super(a_domainFileName, available_time, max_playouts, playoutLookahead, a_ef, a_playoutAI);
		// TODO Auto-generated constructor stub
		ddEnemy = DomainDefinition.fromLispFile("E:\\MK\\myProject\\ahtn2\\ahtntest\\ahtn\\microrts-ahtn-definition-low-level.lisp");
		
	}

    public PlayerAction getAction(int player, GameState gs,boolean partiallyObservable) throws Exception {
    	Term goal1 = Term.fromString("(destroy-player "+player+" "+(1-player)+" "+0+")");
        Term goal2 = Term.fromString("(destroy-player "+(1-player)+" "+player+" "+0+")");
        PlayerAction pa = new PlayerAction();  
        if(gs.canExecuteAnyAction(player))
    	{
    		if(player==0)
               gs.AI1plannum = gs.AI1plannum+1;
             else
               gs.AI2plannum = gs.AI2plannum+1;
    	}
        
        if(partiallyObservable)
        {
        	PartiallyObservableGameState POgs1 = new PartiallyObservableGameState(gs,player);
        	//PartiallyObservableGameState POgs1 = new PartiallyObservableGameState(gs,player,PartialObserveSTRATEGY.RemFixUnit,this);
        	UpdateGameStateNum(POgs1,gs);
        	PlayerAction tm= GetActionbyState(player, POgs1,goal1,goal2,pa);
        	UpdateGameStateNum(gs,POgs1);
        	return tm;
        }
        else
        {
        	return GetActionbyState(player, gs,goal1, goal2,pa);
        }
        
    }
	
	public PlayerAction GetActionbyState(int player, GameState gs,Term goal1,Term goal2,PlayerAction pa) throws Exception
	{
		if (gs.canExecuteAnyAction(player)) 
        {
            Pair<MethodDecomposition,MethodDecomposition> plan = AdversarialBoundedDepthPlannerAlphaBetaforEnemyStrategy.getBestPlanIterativeDeepening(goal1, goal2, player, MAX_TIME, MAX_ITERATIONS, PLAYOUT_LOOKAHEAD, gs, dd,ddEnemy, ef, playoutAI,false);
           //MK
            if(player==0)
            {
            	gs.max_tree_nodesplayer0 = gs.max_tree_nodesplayer0+AdversarialBoundedDepthPlannerAlphaBetaforEnemyStrategy.average_tree_nodes;
            	gs.average_tree_depth0 = gs.average_tree_depth0 + AdversarialBoundedDepthPlannerAlphaBetaforEnemyStrategy.average_tree_depth;
            	gs.renamingIndex0 = gs.renamingIndex0+AdversarialBoundedDepthPlannerAlphaBetaforEnemyStrategy.reInex;
            }
            else
            {
            	gs.max_tree_nodesplayer1 = gs.max_tree_nodesplayer1+AdversarialBoundedDepthPlannerAlphaBetaforEnemyStrategy.average_tree_nodes;
            	gs.average_tree_depth1 = gs.average_tree_depth1 + AdversarialBoundedDepthPlannerAlphaBetaforEnemyStrategy.average_tree_depth;
            	gs.renamingIndex1 = gs.renamingIndex1+AdversarialBoundedDepthPlannerAlphaBetaforEnemyStrategy.reInex;
            }
            //
            
            if (plan.m_a!=null) {
                MethodDecomposition toExecute = plan.m_a;
                List<Pair<Integer,List<Term>>> l = (toExecute!=null ? toExecute.convertToOperatorList():new LinkedList<>());                
                actionsBeingExecuted.clear();
                while(!l.isEmpty()) {
                    Pair<Integer,List<Term>> tmp = l.remove(0);
                    if (tmp.m_a!=gs.getTime()) break;
                    List<Term> actions = tmp.m_b;
                    for(Term action:actions) {
                        MethodDecomposition md = new MethodDecomposition(action);
                        actionsBeingExecuted.add(md);
                    }
                }
            }
            List<MethodDecomposition> toDelete = new LinkedList<>();
            for(MethodDecomposition md:actionsBeingExecuted)
            {
                if (PredefinedOperators.execute(md, gs, pa)) 
                	toDelete.add(md);
                
                for(Pair<Unit,UnitAction> ua:pa.getActions()) {
                    if (gs.getUnit(ua.m_a.getID())==null) {
                        pa.removeUnitAction(ua.m_a, ua.m_b);
                    }
                }
            }
            actionsBeingExecuted.removeAll(toDelete);
            pa.fillWithNones(gs, player, 10);
            return pa;
        } else {
            return new PlayerAction();
        }
	}
}
