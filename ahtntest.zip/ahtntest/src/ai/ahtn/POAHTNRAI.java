package ai.ahtn;

import ai.core.AI;
import ai.evaluation.EvaluationFunction;

public class POAHTNRAI extends EnhanceAHTNAI {

	public POAHTNRAI(String a_domainFileName, int available_time, int max_playouts, int playoutLookahead,
			EvaluationFunction a_ef, AI a_playoutAI) throws Exception {
		super(a_domainFileName, available_time, max_playouts, playoutLookahead, a_ef, a_playoutAI);
		// TODO Auto-generated constructor stub
	}

}
