package ai.ahtn;

import ai.ahtn.domain.HTNMethod;
import ai.core.AI;
import ai.evaluation.EvaluationFunction;
import rts.GameState;
import rts.PlayerAction;

public class TestEnhanceAI extends EnhanceAHTNAI {

	public TestEnhanceAI(String a_domainFileName, int available_time, int max_playouts, int playoutLookahead,
			EvaluationFunction a_ef, AI a_playoutAI) throws Exception {
		super(a_domainFileName, available_time, max_playouts, playoutLookahead, a_ef, a_playoutAI);
		// TODO Auto-generated constructor stub
	}

	//MK
		public PlayerAction LocalReapir(int player, GameState gs,HTNMethod m,PlayerAction pa) throws Exception
		{
			return pa;
		}
		
		 public AI clone() {
		        try {
		            return new TestEnhanceAI(domainFileName, MAX_TIME, MAX_ITERATIONS, PLAYOUT_LOOKAHEAD, ef, playoutAI);
		        }catch(Exception e) {
		            e.printStackTrace();
		            return null;
		        }
		    }
		 public String toString() {
		        return "TestEnhanceAI:"+ curplayer;   //(" + domainFileName + "," + MAX_TIME + ")
		    }
}

