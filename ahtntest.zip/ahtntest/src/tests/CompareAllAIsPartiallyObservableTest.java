/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tests;

import ai.core.AI;
import ai.core.AIWithComputationBudget;
import ai.core.ContinuingAI;
import ai.core.InterruptibleAIWithComputationBudget;
import ai.core.PseudoContinuingAI;
import ai.portfolio.PortfolioAI;
import ai.*;
import ai.abstraction.HeavyRush;
import ai.abstraction.LightRush;
import ai.abstraction.RangedRush;
import ai.abstraction.WorkerRush;
import ai.abstraction.pathfinding.BFSPathFinding;
import ai.abstraction.pathfinding.GreedyPathFinding;
import ai.ahtn.AHTNAI;
import ai.ahtn.EnhanceAHTNAI;
import ai.ahtn.POAHTNRAI;
//import ai.ahtn.EnhanceAHTNAI;
import ai.evaluation.EvaluationFunction;
import ai.evaluation.SimpleSqrtEvaluationFunction;
import ai.evaluation.SimpleSqrtEvaluationFunction2;
import ai.evaluation.SimpleSqrtEvaluationFunction3;
import ai.evaluation.SimpleEvaluationFunction2_test;

import ai.mcts.naivemcts.NaiveMCTS;
import ai.mcts.uct.DownsamplingUCT;
import ai.mcts.uct.UCT;
import ai.mcts.uct.UCTUnitActions;
import ai.minimax.ABCD.IDABCD;
import ai.minimax.RTMiniMax.IDRTMinimax;
import ai.minimax.RTMiniMax.IDRTMinimaxRandomized;
import ai.minimax.RTMiniMax.RTMinimax;
import ai.montecarlo.*;

import java.io.File;
import java.io.PrintStream;
import java.util.LinkedList;
import java.util.List;

import rts.PhysicalGameState;
import rts.units.UnitTypeTable;

/**
 *
 * @author santi
 */
public class CompareAllAIsPartiallyObservableTest {
    
    public static void main(String args[]) throws Exception 
    {
    	boolean CONTINUING = true;
        int TIME = 100;
        int MAX_ACTIONS = 100;
        int MAX_PLAYOUTS = 1;
        int PLAYOUT_TIME = 100;
        int MAX_DEPTH = 10;
        int RANDOMIZED_AB_REPEATS = 10;
        
        String a_domainFileName = "E:\\MK\\myProject\\ahtn2\\ahtntest\\ahtn\\microrts-ahtn-definition-low-level.lisp" ;
        String a_domainFileNameAI = "E:\\MK\\myProject\\ahtn2\\ahtntest\\ahtn\\microrts-ahtn-definition-low-level-phase.lisp" ;
        
        String a_domainFileNameP = "E:\\MK\\myProject\\ahtn2\\ahtntest\\ahtn\\microrts-ahtn-definition-portfolio.lisp" ;
       // String a_domainFileNamePAI = "E:\\MK\\myProject\\ahtn2\\ahtntest\\ahtn\\microrts-ahtn-definition-portfolio-phase.lisp" ;
        String a_domainFileNameFP = "E:\\MK\\myProject\\ahtn2\\ahtntest\\ahtn\\microrts-ahtn-definition-flexible-portfolio.lisp" ;
        String a_domainFileNameFPAI = "E:\\MK\\myProject\\ahtn2\\ahtntest\\ahtn\\microrts-ahtn-definition-flexible-portfolio-phase.lisp" ;
        EvaluationFunction ef = new SimpleSqrtEvaluationFunction2();
        List<AI> bots = new LinkedList<>();
        UnitTypeTable utt = new UnitTypeTable();
      //  AI playout_policytest = new WorkerRush(utt, new BFSPathFinding());
        AI playout_policy =new RandomBiasedAI();
        
        //bots.add(new RandomAI());
 //       bots.add(new RandomBiasedAI());
 //       bots.add(new LightRush(utt, new BFSPathFinding()));
 //       bots.add(new HeavyRush(utt, new BFSPathFinding()));
//    //  bots.add(new WorkerRush(utt, new BFSPathFinding()));
        bots.add(new UCT(TIME, MAX_PLAYOUTS, PLAYOUT_TIME, MAX_DEPTH, playout_policy, ef));
      //bots.add(new IDABCD(TIME, MAX_PLAYOUTS, playout_policy, PLAYOUT_TIME, new SimpleSqrtEvaluationFunction3(), false));
        bots.add(new POAHTNRAI(a_domainFileNameAI,TIME,MAX_PLAYOUTS,PLAYOUT_TIME,ef,playout_policy));      
     // bots.add(new POAHTNRAI(a_domainFileNamePAI,TIME,MAX_PLAYOUTS,PLAYOUT_TIME,ef,playout_policy));         
        bots.add(new POAHTNRAI(a_domainFileNameFPAI,TIME,MAX_PLAYOUTS,PLAYOUT_TIME,ef,playout_policy));
//
       bots.add(new AHTNAI(a_domainFileName,TIME,MAX_PLAYOUTS,PLAYOUT_TIME,ef,playout_policy));
     // bots.add(new AHTNAI(a_domainFileNameP,TIME,MAX_PLAYOUTS,PLAYOUT_TIME,ef,playout_policy));
//       bots.add(new AHTNAI(a_domainFileNameFP,TIME,MAX_PLAYOUTS,PLAYOUT_TIME,ef,playout_policy)); 
      

        if (CONTINUING) {
        	// Find out which of the bots can be used in "continuing" mode:
        	List<AI> bots2 = new LinkedList<>();
        	for(AI bot:bots) {
        		if (bot instanceof AIWithComputationBudget) {
        			if (bot instanceof InterruptibleAIWithComputationBudget) {
        				bots2.add(new ContinuingAI((InterruptibleAIWithComputationBudget)bot));
        			} else {
        				bots2.add(new PseudoContinuingAI((AIWithComputationBudget)bot));        				
        			}
        		} else {
        			bots2.add(bot);
        		}
        	}
        	bots = bots2;
        }        
        
        int map = 16;
        boolean flag = false;
        for(int i=1;i<2;++i)
        {
        	int turntime = i*20;
        	String StrategyName ="FifthStrategy";
        	String outfilename =bots.size()+"_"+ turntime+"_"+StrategyName+"_"+TIME+"_"+MAX_PLAYOUTS+"_"+PLAYOUT_TIME+"_"+"PO_results.txt";
        	if(map==8||flag)
        	{
        		String mapname = "basesWorkers8x8";
                PrintStream out = new PrintStream(new File(mapname+"_"+outfilename));
                PrintStream out1 = new PrintStream(new File(mapname+"_"+"Repair"+outfilename));
                // Separate the matchs by map:
                 List<PhysicalGameState> maps = new LinkedList<PhysicalGameState>();        
                 maps.clear();
                 maps.add(PhysicalGameState.load("maps/"+mapname+".xml",utt));
                 Experimenter.runExperimentsPartiallyObservable(bots, maps, utt, turntime, 3000, 1000, false, out,out1);        //10 ��ʾ ÿ�ֱ���10�Σ� 3000 ��ʾ����frame���� 300��ʾ ��ǰʱ�����ϴζ�������ʱ��Ĳ�ֵ������
        	}
            flag = false;
            if(map==12||flag)
            {
            	String mapname = "basesWorkers12x12";
            	PrintStream out = new PrintStream(new File(mapname+"_"+outfilename));
            	 PrintStream out1 = new PrintStream(new File(mapname+"_"+"Repair"+outfilename));
                // Separate the matchs by map:
            	List<PhysicalGameState> maps = new LinkedList<PhysicalGameState>();        
                maps.clear();
                maps.add(PhysicalGameState.load("maps/"+mapname+".xml",utt));
                Experimenter.runExperimentsPartiallyObservable(bots, maps, utt, turntime, 3000, 1000, true, out,out1);        //10 ��ʾ ÿ�ֱ���10�Σ� 3000 ��ʾ����frame���� 300��ʾ ��ǰʱ�����ϴζ�������ʱ��Ĳ�ֵ������
            }
            
            if(map==16||flag) 
            {
            	String mapname = "basesWorkers16x16";
            	PrintStream  out = new PrintStream(new File(mapname+"_"+outfilename));
            	 PrintStream out1 = new PrintStream(new File(mapname+"_"+"Repair"+outfilename));
                  // Separate the matchs by map:
            	List<PhysicalGameState>  maps = new LinkedList<PhysicalGameState>();        
                maps.clear();
                maps.add(PhysicalGameState.load("maps/"+mapname+".xml",utt));
                Experimenter.runExperimentsPartiallyObservable(bots, maps, utt, turntime, 3000, 1000, true, out,out1);        //10 ��ʾ ÿ�ֱ���10�Σ� 3000 ��ʾ����frame���� 300��ʾ ��ǰʱ�����ϴζ�������ʱ��Ĳ�ֵ������
            }
         
            flag=false;   
           if(map==24||flag) 
           {
        	   String mapname = "basesWorkers24x24";
        	   PrintStream out = new PrintStream(new File(mapname+"_"+outfilename));
        	   PrintStream out1 = new PrintStream(new File(mapname+"_"+"Repair"+outfilename));
               // Separate the matchs by map:
        	   List<PhysicalGameState> maps = new LinkedList<PhysicalGameState>();        
               maps.clear();
               maps.add(PhysicalGameState.load("maps/"+mapname+".xml",utt));
               Experimenter.runExperimentsPartiallyObservable(bots, maps, utt, turntime, 3000, 1000, false, out,out1);        //10 ��ʾ ÿ�ֱ���10�Σ� 3000 ��ʾ����frame���� 300��ʾ ��ǰʱ�����ϴζ�������ʱ��Ĳ�ֵ������
           }
           
        }
    }
}
