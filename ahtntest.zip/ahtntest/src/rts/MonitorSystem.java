package rts;


public class MonitorSystem {
	
	public MonitorSystem()
	{
		
	}
}
