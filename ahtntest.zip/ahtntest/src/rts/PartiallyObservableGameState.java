/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rts;

import java.util.LinkedList;
import java.util.List;
import java.util.Observable;
import java.util.Random;

import ai.ahtn.EnhanceAHTNAI.PartialObserveSTRATEGY;
import ai.core.AI;
import rts.units.Unit;
import rts.units.UnitTypeTable;

/**
 *
 * @author santi
 */
public class PartiallyObservableGameState extends GameState {
    int player;   // the observer player
    
    // creates a partially observable game state, from the point of view of 'player':
    public PartiallyObservableGameState(PhysicalGameState a_pgs, UnitTypeTable a_utt, int a_player) {
        super(a_pgs, a_utt);
        player = a_player;
        Random r = new Random();
    }
    //��֪���ǲ�������ʷ��Ϣ��Ӱ��ģ�����һ��ʵ��۲첻��ʱ������ɾ�����������ǿ���ֻ������
    public PartiallyObservableGameState(GameState gs, int a_player) {
        super(gs.getPhysicalGameState().cloneKeepingUnits(), gs.getUnitTypeTable());
        time = gs.time;
        player = a_player;
        
        Realworld = false; 
        unitActions.putAll(gs.unitActions);
//        for(UnitActionAssignment uaa:gs.unitActions.values()) 
//        {
//            Unit u = uaa.unit;
//
//            int idx = gs.pgs.getUnits().indexOf(u);
//            if (idx==-1) 
//            {
//            	//MK
//            	continue;
//            	//
//            } else {
//                Unit u2 = pgs.getUnits().get(idx);
//                unitActions.put(u2,new UnitActionAssignment(u2, uaa.action, uaa.time));
//            }                
//        }    
        
        List<Unit> toDelete = new LinkedList<Unit>();
        for(Unit u:pgs.getUnits()) 
        {
            if (u.getPlayer() != player) 
            {
                if (!observable(u.getX(),u.getY())) 
                {
                    toDelete.add(u);
                }
            }
        }
        for(Unit u:toDelete)
        {
        	removeUnit(u);   //���ǲ��ڼ�����֪��Χ�ڵ�unit�������Լ���gamestate���Ƴ�
        }  
    }

    public PartiallyObservableGameState(GameState gs, int a_player, PartialObserveSTRATEGY currentPO,AI ai) {
        super(gs.getPhysicalGameState().cloneKeepingUnits(), gs.getUnitTypeTable());
        time = gs.time;
        player = a_player;
        
        Realworld = false; 
        unitActions.putAll(gs.unitActions);
        
		
        List<Unit> toDelete = new LinkedList<Unit>();
        for(Unit u:pgs.getUnits()) 
        {
            if (u.getPlayer() != player) 
            {
                if (!observable(u.getX(),u.getY())) 
                {
                	if(currentPO==PartialObserveSTRATEGY.NOspecial)
                	{
                		toDelete.add(u);
                	}
                	else
                	{
                		if(u.getType().name.equals("Resource")==false&&u.getType().name.equals("Base")==false&&u.getType().name.equals("Barracks")==false)
                		{
                			toDelete.add(u);
                		}
                	}
                }
            }
        }
        for(Unit u:toDelete)
        {
        	removeUnit(u);   //���ǲ��ڼ�����֪��Χ�ڵ�unit�������Լ���gamestate���Ƴ�
        }
        
        //�´��õĵڶ��ε���ʷ��¼
        ai.SecondUnitHistory.clear();
        for(Unit tu:ai.FirstUnitHistory)
        {
        	for(Unit eu:gs.getUnits())
        	{
        		if(eu.getID()==tu.getID()&&eu.getClass()==tu.getClass())
        		{
        			Unit tempu = new Unit(tu);
                	ai.SecondUnitHistory.add(tempu);
        		}
        	}
        }
        
        UpdatePOGameStatebyHistory(gs,a_player,currentPO,ai);
        
      	ai.FirstUnitHistory.clear();
        for(Unit u:pgs.getUnits()) 
        {
        	//Ϊ��һ�μ�¼��һ�� ����Ϣ����ʱPGS��û���Ʋ��ʵ��
        	if(u.IsInferenced)
        		continue;
        	if(u.getType().name.equals("Resource")==true||u.getType().name.equals("Base")==true||u.getType().name.equals("Barracks")==true)
        		continue;
        	Unit tempu = new Unit(u);
        	ai.FirstUnitHistory.add(tempu);
        }         
    }
    public void UpdatePOGameStatebyHistory(GameState gs, int a_player, PartialObserveSTRATEGY currentPO,AI ai) {
		// TODO Auto-generated method stub 
    	if(currentPO==PartialObserveSTRATEGY.RemObservadUnit)
    	{
//    		1��	��¼���й̶�λ�õ�unit
//    		2��	����������ʷ�۲��¼
//    		3��	�����ι۲��¼��ɾ���̶���unit
//    		4��	�����ι۲��¼��ɾ��������unit
//    		5��	����ʷ�۲켯�г�ȥ���ι۲켯���Ѿ����ڵ�unit
//    		6��	��ʷ��¼��ֻ������ʵ�����ģ��������Ʋ��ʵ��
    		 List<Unit> toDelete = new LinkedList<Unit>();
    		for(Unit tu:ai.FirstUnitHistory)
            {
            	for(Unit eu:gs.getUnits())
            	{
            		if(eu.getID()==tu.getID()&&eu.getClass()==tu.getClass())
            		{
            			toDelete.add(tu);
            		}
            	}
            }
    		ai.FirstUnitHistory.removeAll(toDelete);
    		toDelete.clear();
    		for(Unit tu:ai.SecondUnitHistory)
            {
            	for(Unit eu:pgs.getUnits())
            	{
            		if(eu.getID()==tu.getID()&&eu.getClass()==tu.getClass())
            		{
            			toDelete.add(tu);
            		}
            	}
            }
    		ai.FirstUnitHistory.removeAll(toDelete);
    		
    		for(Unit poU:ai.FirstUnitHistory)
    		{
    			if (observable(poU.getX(),poU.getY()))
    			{
    				Unit u=UnObservablePosition(poU.getX(),poU.getY(),poU);
    				u.IsInferenced = true;
    				pgs.units.add(u);
    			}
    			else
    			{
    				for(Unit tu:ai.SecondUnitHistory)
    				{
    					if(poU.getID()==tu.getID()&&poU.getClass()==tu.getClass())
    					{
    						if(poU.getX()==tu.getX()&&poU.getY()==tu.getY())
    						{
    							Unit u = new Unit(poU);
        						pgs.addUnit(u);
        						break;
    						}
    						else
    						{
    							//λ�ò�ͬ��˵��ʵ������Ѿ�����
    							Unit u=UnObservablePosition(poU.getX(),poU.getY(),poU);
    		    				u.IsInferenced = true;
    		    				pgs.units.add(u);
    						}
    					}
    				}
    				//������ϴβ��ɹ�
    				Unit u=UnObservablePosition(poU.getX(),poU.getY(),poU);
    				u.IsInferenced = true;
    				pgs.units.add(u);
    			}
    		}
    		return;
    	}
    	else if(currentPO==PartialObserveSTRATEGY.Inference)
    	{
    		return;
    	}
    	else if(currentPO==PartialObserveSTRATEGY.NOspecial)
    	{
    		return;
    	}
	}
    
    public Unit UnObservablePosition(int x, int y,Unit poU)
    {
    	//���ʵ��λ�ÿɹۣ���һ������Ĳ��ɹ۲�λ��
		int i=1;
		while(true)
		{
			if(!observable(x-i,y)&&(x-i)>=0)
			{
				Unit u = new Unit(poU);
				u.setX(x-i);
				u.setY(y);
				return u;
			}
			if(!observable(x+i,y)&&(x+i<=pgs.width))
			{
				Unit u = new Unit(poU);
				u.setX(x-i);
				u.setY(y);
				return u;
			}
			if(!observable(x,y+1)&&(x+i)<=pgs.height)
			{
				Unit u = new Unit(poU);
				u.setX(x-i);
				u.setY(y);
				return u;
			}
			if(!observable(x,y-1)&&(y-1>=0))
			{
				Unit u = new Unit(poU);
				u.setX(x-i);
				u.setY(y);
				return u;
			}
		}
    }
	public boolean observable(int x, int y) {
    	//���unit�ܹ�������������һ����λ�۲쵽������Ϊ�ǿɹ۵�
        for(Unit u:pgs.getUnits()) {
            if (u.getPlayer() == player) 
            {
                double d = Math.sqrt((u.getX()-x)*(u.getX()-x) + (u.getY()-y)*(u.getY()-y));
                //���Ӹ�֪���ʣ��ø�˹�ֲ�
//                double probility = 10;
//                double pb =Math.abs(r.nextGaussian());
                if (d<=u.getType().sightRadius) 
                	return true;
            }
        }
        
        return false;
    }
    

}
