/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rts;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.*;

import ai.ahtn.domain.Clause;
import ai.core.AI;
import rts.units.Unit;
import rts.units.UnitTypeTable;
import util.Pair;

/**
 *
 * @author santi
 */
public class GameState {
    static Random r = new Random();         // only used if the action conflict resolution strategy is set to random
    
    public Boolean Realworld = false;       //�����ж����㷨���в����������Ƿ���ʵ��������ɵ�����ִ��ʧ�ܣ������ʼ��ȡֵΪTRUE�����ǣ����򲻿���
   
    int unitCancelationCounter = 0;  // only used if the action conflict resolution strategy is set to alternating
    
    int time = 0;
    PhysicalGameState pgs = null;
    HashMap<Unit,UnitActionAssignment> unitActions = new LinkedHashMap<Unit,UnitActionAssignment>();

    UnitTypeTable utt = null;
    //MK
    List<AI> AiList = new LinkedList<AI>();
    
    List<Unit> lastobserveunitsA1 = new LinkedList<Unit>(); 
    List<Unit> lastobserveunitsA2 = new LinkedList<Unit>();
    
    public int playoutAI = -1;
    public float repairnum1 = 0;
    public float repairnum2 = 0;
    
    public float repairfailednum1 = 0;
    public float repairfailednum2 = 0;
    
    public long saveplantimeplayer0 = 0;
    public long saveplantimeplayer1 = 0;
    public long replantimeplayer0 =0;
    public long replantimeplayer1 = 0;
    public float AI1plannum = 0;
    public float AI2plannum = 0;
    
    public long savetimeforPOplayer0 = 0;
    public long savetimeforPOplayer1 = 0;
    
    public double max_tree_nodesplayer0 = 0;
    public double max_tree_nodesplayer1 = 0;
    public double average_tree_depth0 = 0;
    public double average_tree_depth1 = 0;
    
    public double renamingIndex0=0;
    public double renamingIndex1=0;
    
    public long unitnum = 0;
    
    public void addAI(AI ai)
    {
    	AiList.add(ai);
    }
    //
    public GameState(PhysicalGameState a_pgs, UnitTypeTable a_utt) {
        pgs = a_pgs;
        utt = a_utt;
    }
    
    public int getTime() {
        return time;
    }
    
    public void removeUnit(Unit u) { 
    	
    	if(Realworld)
    	{    	
        pgs.removeUnit(u);
       //�����Ų����Щaction�ͻ������쳣�����仰˵��Щaction�Ѿ�ʧ����
       // unitActions.remove(u);   
        //MK
        if(unitActions.get(u)==null)
        	   System.out.printf("there is no such unit:"+u.getID()+"\n");
        else if(unitActions.get(u).action==null)
        	unitActions.remove(u);
        else  if (unitActions.get(u).action.Essential)
        	       {
        	          ProccessFailedAction(unitActions.get(u).action,u);
//        	          if(u.getPlayer()==0)
//        	          System.out.println("falied");
                      HashMap<Unit,UnitActionAssignment> tmpunitActions = new LinkedHashMap<Unit,UnitActionAssignment>();
                      for(UnitActionAssignment uaa:unitActions.values())
         	          {
          	        	  if(!uaa.canremove)
              	        	tmpunitActions.put(uaa.unit, uaa);
              	      }
                      if(tmpunitActions.size()>0)
                          unitActions = tmpunitActions;
        	       }
        else
        	unitActions.remove(u);
//        
//        System.out.printf("Remove :"+u.getID()+"at "+getTime()+"\n");
//        System.out.printf(this+"\n");
    	}
    	else
    	{
    		pgs.removeUnit(u);
    		unitActions.remove(u);
    	}
    	
    }
    
    public Player getPlayer(int ID) {
        return pgs.getPlayer(ID);
    }
    
    public Unit getUnit(long ID) {
        return pgs.getUnit(ID);
    }    
    
    public List<Unit> getUnits() {
        return pgs.getUnits();
    }
    
    public HashMap<Unit,UnitActionAssignment> getUnitActions() {
        return unitActions;
    }
    
    public UnitAction getUnitAction(Unit u) {
        UnitActionAssignment uaa = unitActions.get(u);
        if (uaa==null) return null;
        return uaa.action;
    }    
    
    public UnitActionAssignment getActionAssignment(Unit u) {
        return unitActions.get(u);
    }
    
    public boolean isComplete() {
        for(Unit u:pgs.units) {
            if (u.getPlayer()!=-1) {
                UnitActionAssignment uaa = unitActions.get(u);
                if (uaa == null) return false;
                if (uaa.action == null) return false;
            }
        }
        return true;
    }
    
    public int winner() {
        return pgs.winner();
    }
    
    public boolean gameover() {
        return pgs.gameover();
    }
    
    public PhysicalGameState getPhysicalGameState() {
        return pgs;
    }

    public UnitTypeTable getUnitTypeTable() {
        return utt;
    }
    
    
    // Returns true if there is no unit in the specified position and no unit is executing an action that will use that position
    public boolean free(int x,int y) {
        if (pgs.getTerrain(x, y)!=PhysicalGameState.TERRAIN_NONE) return false;
        for(Unit u:pgs.units) {
            if (u.getX()==x && u.getY()==y) return false;
        }
        for(UnitActionAssignment ua:unitActions.values()) {
            if (ua.action.type==UnitAction.TYPE_MOVE ||
                ua.action.type==UnitAction.TYPE_PRODUCE) {
                Unit u = ua.unit;
                if (ua.action.getDirection()==UnitAction.DIRECTION_UP && u.getX()==x && u.getY()==y+1) return false;
                if (ua.action.getDirection()==UnitAction.DIRECTION_RIGHT && u.getX()==x-1 && u.getY()==y) return false;
                if (ua.action.getDirection()==UnitAction.DIRECTION_DOWN && u.getX()==x && u.getY()==y-1) return false;
                if (ua.action.getDirection()==UnitAction.DIRECTION_LEFT && u.getX()==x+1 && u.getY()==y) return false;
            }
        }
        return true;
    }
    
    //
    public boolean free2(int x,int y,Unit u1) {
        if (pgs.getTerrain(x, y)!=PhysicalGameState.TERRAIN_NONE) 
        	return false;
        for(Unit u:pgs.units)
        {
            if (u.getX()==x && u.getY()==y)
            	return false;
        }
        
        for(UnitActionAssignment ua:unitActions.values()) 
        {
            if (ua.action.type==UnitAction.TYPE_PRODUCE) 
            {
                Unit u = ua.unit;
                if(getTime()!=ua.time&&u.equals(u1))
                	return true;
                if (ua.action.getDirection()==UnitAction.DIRECTION_UP && u.getX()==x && u.getY()==y+1&&!u.equals(u1))
                {
                		return false;
                }
                	
                if (ua.action.getDirection()==UnitAction.DIRECTION_RIGHT && u.getX()==x-1 && u.getY()==y&&!u.equals(u1)) 
                	return false;
                if (ua.action.getDirection()==UnitAction.DIRECTION_DOWN && u.getX()==x && u.getY()==y-1&&!u.equals(u1)) 
                	return false;
                if (ua.action.getDirection()==UnitAction.DIRECTION_LEFT && u.getX()==x+1 && u.getY()==y&&!u.equals(u1)) 
                	return false;
            }
        }
        return true;
    }
    //
    

    // for fully observable game states, all the cells are observable:
    public boolean observable(int x, int y) {
        return true;
    }
    
    
    // returns "true" is any action different from NONE was issued
    public boolean issue(PlayerAction pa) {
        boolean returnValue = false;
        boolean flag = true;
        for(Pair<Unit,UnitAction> p:pa.actions) {
            if (p.m_a==null) {
                System.err.println("Issuing an action to a null unit!!!");
                System.exit(1);
            }
            if (unitActions.get(p)!=null) {
                System.err.println("Issuing an action to a unit with another action!");
            } else {
                // check for conflicts:
                ResourceUsage ru = p.m_b.resourceUsage(p.m_a, pgs);
                for(UnitActionAssignment uaa:unitActions.values()) {
                	//MK
                	if(!uaa.action.canexecuteble)
                		continue;
                	//
                    if (!uaa.action.resourceUsage(uaa.unit, pgs).consistentWith(ru, this)) {
                        // conflicting actions, cancelling both, and replacing them by "NONE":
                        if (uaa.time==time) {
                            // The actions were issued in the same game cycle, so it's normal
                            boolean cancel_old = false;
                            boolean cancel_new = false;
                            switch(utt.getMoveConflictResolutionStrategy()) {
                                default:
                                    System.err.println("Unknown move conflict resolution strategy in the UnitTypeTable!: " + utt.getMoveConflictResolutionStrategy());
                                    System.err.println("Defaulting to MOVE_CONFLICT_RESOLUTION_CANCEL_BOTH");
                                case UnitTypeTable.MOVE_CONFLICT_RESOLUTION_CANCEL_BOTH:
                                    cancel_old = cancel_new = true;
                                    break;
                                case UnitTypeTable.MOVE_CONFLICT_RESOLUTION_CANCEL_RANDOM:
                                    if (r.nextInt(2)==0) cancel_new = true;
                                                    else cancel_old = true;
                                    break;
                                case UnitTypeTable.MOVE_CONFLICT_RESOLUTION_CANCEL_ALTERNATING:
                                    if ((unitCancelationCounter%2)==0) cancel_new = true;
                                                                  else cancel_old = true;
                                    unitCancelationCounter++;
                                    break;
                            }
                            int duration1 = uaa.action.ETA(uaa.unit);
                            int duration2 = p.m_b.ETA(p.m_a);
                            if (cancel_old) 
                            {
                            	//MK
                            	if(uaa.action.Essential)
                            	{
                            		ProccessFailedAction(uaa.action,uaa.unit);
                            		flag = false;
                            	}
                            	else
                            		uaa.action = new UnitAction(UnitAction.TYPE_NONE,Math.min(duration1,duration2),null);
                            	//
                            }
                            if (cancel_new) 
                            {
                            	//MK
                            	if(p.m_b.Essential)
                            	{
                            		ProccessFailedAction(p.m_b,p.m_a);
                            		flag = false;
                            	}
                            	else
                            		p.m_b = new UnitAction(UnitAction.TYPE_NONE,Math.min(duration1,duration2),null);
                            }
                        } else {
                            // This is more a problem, since it means there is a bug somewhere...
                            // (probably in one of the AIs)
                            System.err.println("Inconsistent actions were executed!");
                            System.err.println(uaa);
                            System.err.println("  Resources: " + uaa.action.resourceUsage(uaa.unit, pgs));
                            System.err.println(p.m_a + " assigned action " + p.m_b + " at time " + time);
                            System.err.println("  Resources: " + ru);
                            System.err.println("Player resources: " + pgs.getPlayer(0).getResources() + ", " + pgs.getPlayer(1).getResources());
                            System.err.println("Resource Consistency: " + uaa.action.resourceUsage(uaa.unit, pgs).consistentWith(ru, this));
                            
                            try {
                                throw new Exception("dummy");   // just to be able to print the stack trace
                            }catch(Exception e) {
                                e.printStackTrace();
                            }
                            
                            // only the newly issued action is cancelled, since it's the problematic one...
                            p.m_b = new UnitAction(UnitAction.TYPE_NONE,null);
                        }
                    }
                }
                UnitActionAssignment uaatmp = new UnitActionAssignment(p.m_a, p.m_b, time);
                unitActions.put(p.m_a,uaatmp);
                if(!flag)
                {
                   HashMap<Unit,UnitActionAssignment> tmpunitActions = new LinkedHashMap<Unit,UnitActionAssignment>();
                   for(UnitActionAssignment uaa:unitActions.values())
       	           {
       	        	  if(!uaa.canremove)
       	        		  tmpunitActions.put(uaa.unit, uaa);
       	           }
                   if(tmpunitActions.size()>0)
                   unitActions = tmpunitActions;
                   flag = true;
                }
                if (p.m_b.type!=UnitAction.TYPE_NONE) 
                	returnValue = true;          
            }
        }
        return returnValue;
    }
    
    
    // Returns "true" is any action different from NONE was issued
    public boolean issueSafe(PlayerAction pa) {
        if (!pa.integrityCheck()) throw new Error("PlayerAction inconsistent before 'issueSafe'");
        if (!integrityCheck()) throw new Error("GameState inconsistent before 'issueSafe'");
        
        
        List<Pair<Unit,UnitAction>> toDelete = new LinkedList<Pair<Unit,UnitAction>>();
        
        for(Pair<Unit,UnitAction> p:pa.actions) {
            if (p.m_a==null) {
                System.err.println("Issuing an action to a null unit!!!");
                System.exit(1);
            }
            
            // get the unit that corresponds to that action (since the state might have been closed):
            if (pgs.units.indexOf(p.m_a)==-1) {
                boolean found = false;
                for(Unit u:pgs.units) {
                    if (u.getClass()==p.m_a.getClass() &&
//                        u.getID() == p.m_a.getID()) {
                        u.getX()==p.m_a.getX() &&
                        u.getY()==p.m_a.getY()) {
                        p.m_a = u;
                        found = true;
                        break;
                    }
                }
                if (!found) {
                   
                	toDelete.add(p);
                	System.err.println("Inconsistent order: " + pa);
                    System.err.println("at: " + getTime());
                    System.err.println(this);
                    System.err.println("The problem was with unit " + p.m_a);
                }
            }
        }
        if(toDelete.size()>0)
          pa.actions.removeAll(toDelete);
        
        boolean returnValue = issue(pa);
        if (!integrityCheck()) throw new Error("GameState inconsistent after 'issueSafe': " + pa);        
        return returnValue;
    }    
    
        
    public boolean canExecuteAnyAction(int pID)
    {
        for(Unit u:pgs.getUnits()) {
            if (u.getPlayer()==pID) {
                if (unitActions.get(u)==null) 
                	return true;
            }
        }
        return false;
    }
    
    
    public boolean isUnitActionAllowed(Unit u, UnitAction ua) {
        PlayerAction empty = new PlayerAction();

        // Generate the reserved resources:
        for(Unit u2:pgs.getUnits()) {
                UnitActionAssignment uaa = unitActions.get(u2);
                if (uaa!=null) {
                    ResourceUsage ru = uaa.action.resourceUsage(u2, pgs);
                    empty.r.merge(ru);
                }
        }
        
        if (ua.resourceUsage(u, pgs).consistentWith(empty.getResourceUsage(), this)) return true;
        
        return false;
    }
    
    
    public List<PlayerAction> getPlayerActionsSingleUnit(int pID, Unit unit) {
        List<PlayerAction> l = new LinkedList<PlayerAction>();
        
        PlayerAction empty = new PlayerAction();
        l.add(empty);
        
        // Generate the reserved resources:
        for(Unit u:pgs.getUnits()) {
//            if (u.getPlayer()==pID) {
                UnitActionAssignment uaa = unitActions.get(u);
                if (uaa!=null) {
                    ResourceUsage ru = uaa.action.resourceUsage(u, pgs);
                    empty.r.merge(ru);
                }
//            }
        }
        
        if (unitActions.get(unit)==null) {
            List<PlayerAction> l2 = new LinkedList<PlayerAction>();

            for(PlayerAction pa:l) {
                l2.addAll(pa.cartesianProduct(unit.getUnitActions(this), unit, this));
            }
            l = l2;
        }
        
        return l;
    }
    
    
    public List<PlayerAction> getPlayerActions(int pID) {
        List<PlayerAction> l = new LinkedList<PlayerAction>();
        
        PlayerAction empty = new PlayerAction();
        l.add(empty);
        
        // Generate the reserved resources:
        for(Unit u:pgs.getUnits()) {
//            if (u.getPlayer()==pID) {
                UnitActionAssignment uaa = unitActions.get(u);
                if (uaa!=null) {
                    ResourceUsage ru = uaa.action.resourceUsage(u, pgs);
                    empty.r.merge(ru);
                }
//            }
        }
        
        for(Unit u:pgs.getUnits()) {
            if (u.getPlayer()==pID) {
                if (unitActions.get(u)==null) {
                    List<PlayerAction> l2 = new LinkedList<PlayerAction>();

                    for(PlayerAction pa:l) {
                        l2.addAll(pa.cartesianProduct(u.getUnitActions(this), u, this));
                    }
                    l = l2;
                }
            }
        }
        
        return l;
    }
        
       
    public int getNextChangeTime() {
        int nct = -1;
        
        for(Player player:pgs.players) {
            if (canExecuteAnyAction(player.ID)) return time;
        }
        
        for(UnitActionAssignment uaa:unitActions.values()) {
            int t = uaa.time + uaa.action.ETA(uaa.unit);
            if (nct==-1 || t<nct) nct = t;
        }
        
        if (nct==-1) return time;
        return nct;
    }
        
    
    public boolean cycle() {
        time++;
        
        List<UnitActionAssignment> readyToExecute = new LinkedList<UnitActionAssignment>();
        for(UnitActionAssignment uaa:unitActions.values()) 
        {       	 
        	//MK
        	if(!uaa.action.canexecuteble)
        		continue;
        	//
            if (uaa.action.ETA(uaa.unit)+uaa.time<=time) readyToExecute.add(uaa);
        }
                
        // execute the actions:
        for(UnitActionAssignment uaa:readyToExecute) 
        {
            unitActions.remove(uaa.unit); 
//            System.out.println("Executing action for " + u + " issued at time " + uaa.time + " with duration " + uaa.action.ETA(uaa.unit));           
            uaa.action.execute(uaa.unit,this);
            if(Realworld)
            {
            	uaa.action.status = 1;
            	ProccessSuccessAction(uaa.action,uaa.unit);
            }
        }
        
        return gameover();
    }
    
    
    public void forceExecuteAllActions() {
        List<UnitActionAssignment> readyToExecute = new LinkedList<UnitActionAssignment>();
        for(UnitActionAssignment uaa:unitActions.values()) readyToExecute.add(uaa);
                
        // execute all the actions:
        for(UnitActionAssignment uaa:readyToExecute) {
            unitActions.remove(uaa.unit);
            uaa.action.execute(uaa.unit,this);
        }
    }
    
    public GameState clone() {
        GameState gs = new GameState(pgs.clone(), utt);
        gs.time = time;
        gs.unitCancelationCounter = unitCancelationCounter;
        gs.playoutAI = playoutAI;
        for(UnitActionAssignment uaa:unitActions.values()) 
        {
        	//MK ���������ݹ����в������ж���ʧ��       		
        	if(!uaa.action.canexecuteble&&!gs.Realworld)
        		continue;
        	//
            Unit u = uaa.unit;
            int idx = pgs.getUnits().indexOf(u);
            if (idx==-1) 
            {
                System.out.println("Problematic game state:");
                System.out.println(this);
                System.out.println("Problematic action:");
                System.out.println(uaa);
                System.out.println(u);
                throw new Error("Inconsistent game state during cloning...");
            } else {
                Unit u2 = gs.pgs.getUnits().get(idx);
                gs.unitActions.put(u2,new UnitActionAssignment(u2, uaa.action, uaa.time));
            }                
        }
        return gs;
    }
    
    // This method does a quick clone, that shares the same PGS, but different unit assignments:
    public GameState cloneIssue(PlayerAction pa) {
        GameState gs = new GameState(pgs, utt);
        gs.time = time;
        gs.unitCancelationCounter = unitCancelationCounter;
//        if (!integrityCheck()) throw new Error("Game State inconsistent before adding action");
        gs.unitActions.putAll(unitActions);
        gs.playoutAI = playoutAI;
/*
        for(Pair<Unit,UnitAction> ua:pa.actions) {
            if (pgs.units.indexOf(ua.m_a)==-1) {
                System.err.println("Unit " + ua.m_a + " does not exist in game state:\n" + pgs);
                System.exit(1);
            }
        }
*/
        gs.issue(pa);
//        if (!integrityCheck()) throw new Error("Game State inconsistent after adding action");
        return gs;        
    }
    
    
    public ResourceUsage getResourceUsage() {
        ResourceUsage base_ru = new ResourceUsage();
        
        for(Unit u:pgs.getUnits()) {
            UnitActionAssignment uaa = unitActions.get(u);
            if (uaa!=null) {
                ResourceUsage ru = uaa.action.resourceUsage(u, pgs);
                base_ru.merge(ru);
            }
        }
        
        return base_ru;
    }
    
    
    public boolean integrityCheck() {
        List<Unit> alreadyUsed = new LinkedList<Unit>();
        for(UnitActionAssignment uaa:unitActions.values()) {
        	
        	//MK ɸѡ�����в���ִ�е�action
        	if(!uaa.action.canexecuteble)
        	    continue;
        	//	
            Unit u = uaa.unit;
            int idx = pgs.getUnits().indexOf(u);
            if (idx==-1) {
                System.err.println("integrityCheck: unit does not exist!"); 
                return false;
            }            
            if (alreadyUsed.contains(u)) {
                System.err.println("integrityCheck: two actions to the same unit!");
                return false;
            }
            alreadyUsed.add(u);
        }
        return true;
    }
            
    
    public void dumpActionAssignments() {
        for(Unit u:pgs.getUnits()) {
            if (u.getPlayer()>=0) {
                UnitActionAssignment uaa = unitActions.get(u);
                if (uaa==null) {
                    System.out.println(u + " : -");
                } else {
                    System.out.println(u + " : " + uaa.action + " at " + uaa.time);                    
                }
            }
            
        }
    }
    
    public String toString() {
        String tmp = "ObservableGameState: " + time + "\n";
        for(Player p:pgs.getPlayers()) tmp += "player " + p.ID + ": " + p.getResources() + "\n";
        for(Unit u:unitActions.keySet()) {
            UnitActionAssignment ua = unitActions.get(u);
            if (ua==null) {
                tmp += "    " + u + " -> null (ERROR!)\n";
            } else {
                tmp += "    " + u + " -> " + ua.time + " " + ua.action + "\n";
            }
        }
        tmp += pgs;
        return tmp;
    }
    
    //MK
    public void ProccessFailedAction(UnitAction action,Unit u)
    {
    	if(Realworld)
    	{
    		action.canexecuteble = false;
    		
    		//����HTN�������Ľṹ����������Ӱ�������
    		int playerID = u.getPlayer();
        	for(AI ai:AiList)
        	{
        		if(ai.getPlayerID()==playerID)
        		{
        			ai.ProccessFailedAction(action,this,playerID);
        			break;
        		}
        	}
        }
    }
    
    //MK
    public void ProccessSuccessAction(UnitAction action,Unit u)
    {
    	if(Realworld)
    	{
    		int playerID = u.getPlayer();
        	for(AI ai:AiList)
        	{
        		if(ai.getPlayerID()==playerID)
        		{
        			ai.ProccessSuccessAction(action,this,playerID);
        			break;
        		}
        	}
        }
    }
    
}
